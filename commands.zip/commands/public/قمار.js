const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Emojis.ttf", "Emojis");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");
    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/komar.png";
    if (
      (await times.get(`قمار_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`قمار_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `:x: | \`${
          parse(
            (await times.get(`قمار_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`قمار_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\` , أنتظر لاهنت`,
      });
    let amount = args[0];
    if (!amount)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
>>> قمار المبلغ`);
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    let yourCarrancy = (await bank.get(`money_${msg.author.id}`)) ?? "0";

    if (amount == "نص") amount = String(Number(yourCarrancy) / 2);
    if (amount == "ربع") amount = String(Number(yourCarrancy) / 4);
    if (amount == "كامل") amount = String(Number(yourCarrancy));
    if (amount == "كل") amount = String(Number(yourCarrancy));

    if (amount.includes("-") || !isNumber(amount))
      return msg.reply("يرجى ادخال رقم صحيح ");
    if (Number(amount) > Number(yourCarrancy))
      return msg.reply("ليس لديك رصيد كافي");

    let types = ["🍒", "🍇", "🍎", "🍏", "🍊", "🍅", "🍋"];
    let a1 = types[Math.floor(Math.random() * types.length)];
    let a2 = types[Math.floor(Math.random() * types.length)];
    let a3 = types[Math.floor(Math.random() * types.length)];
    let condetion = "lose";

    if (a1 == a2 || a1 == a3 || a2 == a3) condetion = "win";
    if (condetion == "lose")
      await bank.set(
        `money_${msg.author.id}`,
        String(Number(yourCarrancy) - Number(amount))
      );
    else
      await bank.set(
        `money_${msg.author.id}`,
        String(
          Number(await bank.get(`money_${msg.author.id}`)) + Number(amount * 2)
        )
      );

    async function createCanvas() {
      const image = await loadImage(imageURL);
      const avatar = await loadImage(msg.author.avatarURL({ size: 2048 }));

      const firstStage = new Canvas(700, 250)
      .printImage(image, 0, 0, 700, 250)
      .createRoundedClip(500, 50, 150, 150, 360)
      .setColor("#000000")
      .createCircularClip(575, 125, 75)
      .printImage(avatar, 500, 50, 150, 150)
      .pngAsync();
      const stageImage = await loadImage(await firstStage);
      const sacandStage = new Canvas(700, 250)
        .printImage(stageImage, 0, 0, 700, 250)
        .setTextFont("62px Emojis")
        .setColor("#808080")
        .printText(a1, 90, 145)
        .printText(a2, 190, 145)
        .printText(a3, 290, 145)
        .setTextAlign("center")
        .setTextFont("42px Cairo")

        .printText(condetion == "lose" ? "لقد خسرت" : "لقد فزت", 350, 50)
        .pngAsync();
      let tabel = await db.tableAsync("base");
      let imageB = await tabel.get(`image_${msg.guild.id}`);

      if (imageB) {
        const lastImage = await loadImage(imageB);
        const last = new Canvas(700, 250)
          .printImage(lastImage, 0, 0, 700, 250)
          .setGlobalAlpha(0.9)
          .printImage(await loadImage(await sacandStage), 0, 0, 700, 250)
          .pngAsync();

        return await last;
      } else return await sacandStage;
    }
    let resultImage = new AttachmentBuilder(await createCanvas(), {
      name: "7lm.png",
    });
    times.set(
      `قمار_${msg.guild.id}_${msg.author.id}`,
      new Date().getTime() + 300000
    );
    let msi = await msg.reply({ files: [resultImage] });
    if (isEmbed)
      msi.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(embedColor)
            .setImage("attachment://7lm.png"),
        ],
      });
  }
};
