const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let times = await db.tableAsync("times");

    async function doCheck(params) {
      if (
        (await times.get(`${params}_${msg.guild.id}_${msg.author.id}`)) &&
        (await times.get(`${params}_${msg.guild.id}_${msg.author.id}`)) >
          new Date().getTime()
      )
        return `${
          parse(
            (await times.get(`${params}_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } دقائق, ${
          parse(
            (await times.get(`${params}_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } ثواني `;
      else return "✅";
    }

    msg.reply({
      embeds: [
        {
          author: {
            name: msg.author.username,
            icon_url: msg.author.avatarURL(),
          },
          timestamp: new Date(),
          description: `\`تداول\` | ${await doCheck(
            "تداول"
          )}\n\`فواكه\` | ${await doCheck("فواكه")}\n\`نهب\` | ${await doCheck(
            "نهب"
          )}\n\`راتب\` | ${await doCheck("راتب")}\n\`بخشيش\` | ${await doCheck(
            "بخشيش"
          )}\n\`قرض\` | ${await doCheck("قرض")}\n\`قمار\` | ${await doCheck(
            "قمار"
          )}\n\`لعبه\` | ${await doCheck(
            "لعبه"
            )}\n\`لون\` | ${await doCheck(
              "لون"
              )}\n\`حظ\` | ${await doCheck(
                "حظ"
          )}\n\`استثمار\` | ${await doCheck("استثمار")}\n`,
        },
      ],
    });
  }
};
