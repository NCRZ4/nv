const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let times = await db.tableAsync("times");

    let emojis = ["✂️", "🧱", "📰"];
    if (
      (await times.get(`لعبه_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`لعبه_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `:x: | \`${
          parse(
            (await times.get(`لعبه_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`لعبه_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\` , أنتظر لاهنت`,
      });
    msg
      .reply({
        embeds: [
          {
            color: 0xffffff,
            title: "حجرة, ورقة, مقص",
            description: "عند الفوز ستحصل على **1000$**",
            footer: { text: "عند الخسارة او التعادل تروح عليك الألف" },
          },
        ],
      })
      .then((m) => {
        emojis.forEach((e) => {
          m.react(e);
        });
        m.createReactionCollector({
          max: 1,
          filter: (_0, user) => user.id == msg.author.id,
        }).on("collect", async (r, user) => {
          let botChoose = emojis[Math.floor(Math.random() * emojis.length)];
          let yourChoose = r.emoji.name;
          let bank = await db.tableAsync("bank");
          let userCrrancy = (await bank.get(`money_${user.id}`)) ?? "0";
          times.set(
            `لعبه_${msg.guild.id}_${msg.author.id}`,
            new Date().getTime() + 300000
          );
          if (botChoose == "📰" && yourChoose == "✂️") doEvevryThing();
          else if (botChoose == "🧱" && yourChoose == "📰") doEvevryThing();
          else if (botChoose == "✂️" && yourChoose == "🧱") doEvevryThing();
          else {
            m.edit({
              embeds: [
                {
                  color: 0xffffff,
                  title: "حجرة, ورقة, مقص",
                  description: "❌ لقد خسرت راحت عليك الـ **1000$**",
                  footer: {
                    text: `انت أخترت ${yourChoose}, انا اخترت ${botChoose}`,
                  },
                },
              ],
            });
          }

          async function doEvevryThing() {
            m.edit({
              embeds: [
                {
                  color: 0xffffff,
                  title: "حجرة, ورقة, مقص",
                  description: "✅ لقد فزت وكسبت **1000$**",
                  footer: {
                    text: `انت أخترت ${yourChoose}, انا اخترت ${botChoose}`,
                  },
                },
              ],
            });
            await bank.set(
              `money_${user.id}`,
              String(Number(userCrrancy) + Number(1000))
            );
          }
        });
      });
  }
};
