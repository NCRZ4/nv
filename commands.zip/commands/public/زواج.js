const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");

const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let zwagat = await db.tableAsync("zwagat");

    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/zwag.png";

    let zwagList = (await zwagat.get("list")) ?? [];
    let amount = args[1];
    let user =
      msg.guild.members.cache.get(args[0])?.user || msg.mentions.users.first();
    if (user?.bot) return msg.reply("هاه ؟؟ :)");
    if (!user || !amount)
      return msg.reply(`**منشن فتاة الاحلام وحط المهر**`);
    if (user.id == msg.author.id) return msg.reply("تتزوج نفسك ؟ 🙂");
    if (Number(amount) < 50000) return msg.reply("**مانزوج بناتنا بأقل من خمسين ألف**");
    
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    let yourCarrancy = (await bank.get(`money_${msg.author.id}`)) ?? "0";
    if (amount == "نص") amount = String(Number(yourCarrancy) / 2);
    if (amount == "ربع") amount = String(Number(yourCarrancy) / 4);
    if (amount == "كامل") amount = String(Number(yourCarrancy));
    if (amount == "كل") amount = String(Number(yourCarrancy));

    if (amount.includes("-") || !isNumber(amount))
    return msg.reply("**يرجى ادخال رقم صحيح**");
    if (Number(amount) > Number(yourCarrancy))
    return msg.reply("**ليس لديك رصيد كافي**");
    let status = "ok";
    zwagList.forEach((zwag) => {
      if (zwag.man == user.id || zwag.woman == user.id)
        status = `<@${user.id}> متزوجه اصلاََ`;
      if (zwag.woman == msg.author.id) status = "**انتي متزوجه اصلاََ 🤡**";
      if (zwag.man == msg.author.id) status = "**انت متزوج اصلاََ 🤡**";
    });

    setTimeout(async () => {
      if (status !== "ok") return msg.reply(status);
      
      await msg
        .reply({
          embeds: [
            {
              title: "طلب زواج 💍",
            
            },
            
          ]
        })
        .then(async (m) => {
          await m.react("💍");
          await m.react("❌");
          await m
            .createReactionCollector({
              filter: (args_0, user2) => user2.id == user.id,
              max: 1,
            })
            
            .on("collect", async (reaction, user) => {
              await m.reactions.removeAll();
              if (reaction.emoji.name == "💍") {
                let current = (await bank.get(`money_${msg.author.id}`)) ?? "0";
                let current2 = (await bank.get(`money_${user.id}`)) ?? "0";
                await bank.set(
                  `money_${msg.author.id}`,
                  String(Number(current) - Number(amount))
                );
                await bank.set(
                  `money_${user.id}`,
                  String(Number(current2) + Number(amount))
                );
                async function createCanvas() {
                  const image = await loadImage(imageURL);
                  const avatar = await loadImage(msg.author.avatarURL());
                  const avatar2 = await loadImage(user.avatarURL());
          
                  const firstStage = new Canvas(600, 700)
                  .printImage(image, 0, 0, 600, 700)
                  .setColor("#000000")
                  .createCircularClip(150, 270, 90)
                  .printImage(avatar, 60, 180, 180, 180)
                  .pngAsync();
                  const image2 = await loadImage(await firstStage);

                  const sacandStager = new Canvas(600, 700)
                  .printImage(image2, 0, 0, 600, 700)
                  .setColor("#000000")
                  .createCircularClip(450, 270, 90)
                  .printImage(avatar2, 360, 180, 180, 180)
                  .pngAsync();

                  const sacandStage = new Canvas(600, 700)
                    .printImage(
                      await loadImage(await sacandStager),
                      0,
                      0,
                      600,
                      700
                    )
                    .setColor("#FFFFFF")
                    .setTextFont("bold 30px Cairo")
                    .setTextAlign("center")
                    .printText(
                      "بالمهر المدون اسفلاََََ وذالك بالتراضي بين",
                      300,
                      450
                    )
                    .printText("الطرفين ، وقد شهد ذالك الجميع", 300, 450 + 48)
                    .printText(String(amount) + "$", 300, 620)
                    
                    .printText("تم عقد زواج كلّا من", 300, 160 )
                    .printText(" عقد زواج  ", 300, 70 )
                    .pngAsync();

                  let tabel = await db.tableAsync("base");
                  let imageB = await tabel.get(`image_${msg.guild.id}`);

                  if (imageB) {
                    const lastImage = await loadImage(imageB);
                    const last = new Canvas(600, 700)
                      .printImage(lastImage, 0, 0, 600, 700)
                      .setGlobalAlpha(0.9)
                      .printImage(
                        await loadImage(await sacandStage),
                        0,
                        0,
                        600,
                        700
                      )
                      .pngAsync();

                    return await last;
                  } else return await sacandStage;
                }
                let resultImage = new AttachmentBuilder(await createCanvas(), {
                  name: "7lm.png",
                });
                await zwagat.push(`list`, {
                  man: msg.author.id,
                  woman: user.id,
                  date: `\`${new Date().getFullYear()}-${new Date().getMonth()}-${new Date().getDay()}\``,
                  mahr: amount,
                });
                let msi = await m.edit({ files: [resultImage], embeds: [] });
                if (isEmbed)
                  msi.edit({
                    embeds: [
                      new EmbedBuilder()
                        .setColor(embedColor)
                        .setImage("attachment://7lm.png"),
                    ],
                  });
              } else {
                m.edit({
                  embeds: [
                    {
                      title: "احم ... اصلاََ عادي 🙂",
                    },
                    
                  ],
                });
              }
              
            });
        });
    });
  }
};
