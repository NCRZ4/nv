const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");
const { EventEmitter } = require("node:events");
const { FindEmoji } = require("discord-gamecord");
const { QuickDB } = require("quick.db");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let times = await db.tableAsync("times");

    if (
      (await times.get(`فواكه_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`فواكه_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `❌ | \`${
          parse(
            (await times.get(`فواكه_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`فواكه_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\` , أنتظر لاهنت`,
      });
    const Game = new FindEmoji({
      message: msg,
      isSlashGame: false,
      embed: {
        title: "فواكة",
        color: "#5865F2",
        description: "تذكر اماكن ال الفواكة",
        findDescription: "اعثر على {emoji} قبل نفاذ الوقت!!. واربح 1500",
      },
      timeoutTime: 6000,
      hideEmojiTime: 5000,
      buttonStyle: "PRIMARY",
      emojis: ["🍉", "🍇", "🍊", "🍋", "🥭", "🍎", "🍏", "🥝"],
      winMessage: "  الف مبروك فزت ب 1500 🎉",
      loseMessage: "لقد خسرت ال الفاكها كانت {emoji}",
      timeoutMessage: "لقد خسرت ال الفاكها كانت {emoji}",
      playerOnlyMessage: "فقط {player} يقدر يلعب.",
    });

    Game.startGame();
    Game.on("", async (result) => {
      if (result.result == "win") {
        let carncy = (await bank.get(`money_${msg.author.id}`)) ?? "0";
        await bank.set(`money_${msg.author.id}`, String(Number(carncy) + 1500));
      }
    });
  
    times.set(
      `فواكه_${msg.guild.id}_${msg.author.id}`,
      new Date().getTime() + 300000
    );
  }
};
