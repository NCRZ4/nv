const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");
const parse = require("parse-ms");
const generateSpinWheel = require("../../utils/wheelspin");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");

    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";

    if (
      (await times.get(`حححححظ_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`حححححظ_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `❌ | \`${
          parse(
            (await times.get(`ححححظ_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`ححححظ_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\` باقي على الحظ :`,
      });
    const FRAME_DELAY_MS = 50;
    const MAX_DURATION_MS = 5000;
    const LAST_FRAME_DURATION_MS = 1000 / FRAME_DELAY_MS;
    const MIN_ANGLE = 360;
    const MAX_ANGLE = 360 * 8;
    const DURATION = MAX_DURATION_MS / FRAME_DELAY_MS;

    const styles = {
      canvas: {
        width: 250,
        height: 250,
      },
    };
    const options = [
      "100",
      "500",
      "1000000",
      "300",
      "100000",
      "900",
      "50000",
      "300000",
      "100000",
      "50",
    ];

    const loadingMessageEmbed = new EmbedBuilder()
      .setTitle("ححححظ")
      .setDescription("جاري تحميل العبة...");

    const loadingMessage = await msg.reply({
      embeds: [loadingMessageEmbed],
    });

    const randomEndAngle = Math.random() * (MAX_ANGLE - MIN_ANGLE) + MIN_ANGLE;

    const wheel = generateSpinWheel(
      options,
      randomEndAngle,
      DURATION,
      FRAME_DELAY_MS,
      styles.canvas.width,
      styles.canvas.height,
      LAST_FRAME_DURATION_MS
    );

    const spinWheelAttachment = new AttachmentBuilder(wheel.getGif(), {
      name: "spin-wheel.gif",
    });

    const message = await loadingMessage.edit({
      embeds: [
        new EmbedBuilder()
          .setTitle("حححححظ")
          .setImage("attachment://spin-wheel.gif"),
      ],
      files: [spinWheelAttachment],
    });

    setTimeout(async () => {
      const selectedOptionAttachmment = new AttachmentBuilder(
        wheel.getLastFrame(),
        { name: "last-option.png" }
      );

      await message.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(wheel.selectedOptionColor)
            .setTitle("حححححظ")
            .setDescription(
              ` **الف مبروك ربحت نصيبك من حظك** **\`${wheel.selectedOption}\`**`
            )
            .setImage("attachment://last-option.png"),
        ],
        files: [selectedOptionAttachmment],
      });
      let current = (await bank.get(`money_${msg.author.id}`)) ?? "0";
      await bank.set(
        `money_${msg.author.id}`,
        String(Number(current) + Number(wheel.selectedOption))
      );
      times.set(
        `ححححظ_${msg.guild.id}_${msg.author.id}`,
        new Date().getTime() + 300000
      );
    }, MAX_DURATION_MS);
  }
};
