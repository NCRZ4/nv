const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let zwagat = await db.tableAsync("zwagat");
    let list = await zwagat.get("list") ?? [];

    msg.reply({
      allowedMentions: { repliedUser: false },
      embeds: [
        {
          thumbnail: {
            url: "https://media.discordapp.net/attachments/1105475002784034908/1124703353973264414/wedding-couple.png?width=554&height=554",
          },
          author: {
            name: "قائمة الزواجات 💑",
            icon_url: msg.guild.iconURL(),
          },
          description: list
            .map((object, index) => `${index + 1} : **:person_in_tuxedo: <@${object.man}> | :person_with_veil: <@${object.woman}>**`)
            .join("\n"),
        },
      ],
    });
  }
};
