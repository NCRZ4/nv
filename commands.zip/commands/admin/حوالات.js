const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let baseData = await db.tableAsync("base");
    let toggle = (await baseData.get(`حوالات_${msg.guild.id}`)) ?? false;
    await baseData.set(`حوالات_${msg.guild.id}`, toggle == false ? true : false);
    if (toggle == false) {
      msg.react("🗑");
      msg.reply({
        allowedMentions: { repliedUser: false },
        content: " تم أيقاف نظام الحوالات",
      });
      event.emit("log", msg.guild, {
        author: msg.author,
        date: new Date(),
        value: `تم أيقاف نظام الحوالات`,
      });
  } else {
    msg.react("✅");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "تم تفعيل نظام الحوالات",
    });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: `تم تفعيل نظام الحوالات`,
    });
  }
  };
}
