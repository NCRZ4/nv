const { Message } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let channel =
      msg.mentions.channels.first() ||
      msg.guild.channels.cache.get(args[0]) ||
      msg.channel;
    let baseData = await db.tableAsync("base");
    if (
      (await baseData.get(`bankChannel_${msg.guild.id}`)) &&
      channel.id == (await baseData.get(`bankChannel_${msg.guild.id}`))
    ) {
      await baseData.delete(`bankChannel_${msg.guild.id}`);
      msg.react("🗑");
      msg.reply({
        allowedMentions: { repliedUser: false },
        content: "🗑 تم أيقاف نظام البنك",
      });
      event.emit("log", msg.guild, {
        author: msg.author,
        date: new Date(),
        value: `أيقاف نظام البنك`,
      });
      return;
    }
    await baseData.set(`bankChannel_${msg.guild.id}`, channel.id);
    msg.react("✅");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "🏧 تم تفعيل نظام البنك في روم <#" + channel.id + ">",
    });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: `تفعيل نظام البنك في روم ${channel.id}`,
    });
  }
};
