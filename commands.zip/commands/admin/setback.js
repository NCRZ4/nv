const {
  Message,
  Embed,
  EmbedBuilder,
  AttachmentBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder,
} = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    if (config.userDefaltImages == true)
      return msg.reply("جميع الصور يتم تحميلها من البوت ");
    let image = msg.attachments.first()?.url || args[0];
    if (!image)
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content:
          ":x: يرجى ارسال ملف الصورة مرفق مع رسالة او كتابة رابط الصورة ",
      });

    let baseData = await db.tableAsync("base");
    await baseData.set(`image_${msg.guild.id}`, image);
    msg.react("🎨");
    msg
      .reply({
        components: [],
        allowedMentions: { repliedUser: false },
        content: "🎨 تم تغير صورة البوت",
      })
      .then(async (m) => {
        let toggle = (await baseData.get(`e_${msg.guild.id}`)) ?? false;
        let color = (await baseData.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
        if (toggle)
          m.edit({
            embeds: [
              new EmbedBuilder()
                .setColor(color)
                .setImage("attachment://image.png"),
            ],
            files: [new AttachmentBuilder(image, { name: "image.png" })],
          });
        else
          m.edit({
            files: [new AttachmentBuilder(image, { name: "image.png" })],
          });
      });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: `تغير صورة البوت لـ ${image}`,
    });
  }
};
