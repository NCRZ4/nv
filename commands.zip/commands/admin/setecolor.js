const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    function isHexColor(input) {
      var hexPattern = /#?([A-F]|[a-f]|\d){6}$/;
      return hexPattern.test(input);
    }
    if (!args[0])
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content:
          ":x: يرجى كتابة ال هيكس كودالخاص بالون المراد تحديده كـ لون الأيمبد ",
      });
      if (!isHexColor(args[0])) return msg.reply({
        allowedMentions: { repliedUser: false },
        content:
          ":x: هيكس كود خاطأ",
      });
    let baseData = await db.tableAsync("base");
    await baseData.set(`eColor_${msg.guild.id}`, args[0]);
    msg.react("✅");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "🎨 تم تغير لون الأيمبد",
      embeds: [new EmbedBuilder().setColor(args[0]).setDescription("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _")],
    });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: `تغير لون الأيمبد لـ ${args[0]}`,
    });
  }
};
