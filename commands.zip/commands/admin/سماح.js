const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let blacklist = await db.tableAsync("blacklist");
    let user =
      msg.mentions.users.first() || msg.guild.members.cache.get(args[0])?.user;
      if (user?.bot) return msg.reply("اقول وخر عن البوتات 😡")
    if (!user)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
>>> سماح @منشن`);
    if (user.id == msg.author.id) return msg.reply("");
    if (user?.bot) return msg.reply("");
    let list = await blacklist.get(msg.guild.id);
    if (!list || !list?.includes(user.id))
      return msg.reply("الشخص مو موجود اصلاََ ...");
    blacklist.pull(`${msg.guild.id}`, user.id);
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "تم السماح للشخص بأستعمال البوت",
    });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: `تم السماح ل <@!${user.id}> بالعب`,
    });
  }
};
