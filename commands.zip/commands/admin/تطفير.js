const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let bank = await db.tableAsync("bank");
    let حرامية = await db.tableAsync("حرامية");
    let زواجات = await db.tableAsync("zwagat");

    await زواجات.delete("list");
    await حرامية.delete("list");
    (await bank.all()).forEach(async ({ id }) => {
      if (id.startsWith("money_")) await bank.delete(id);
    });
    msg.react("💰");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "الكل صار على الجنط 👍",
    });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: `السيرفر كله صار مطفر`,
    });
  }
};